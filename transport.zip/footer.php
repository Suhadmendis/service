<style>

    .sf-bottom-list li img {
        float: left;
        margin-right: 5px;
    }
</style>

<footer class="footer">

</footer>


