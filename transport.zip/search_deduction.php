<?php
session_start();
include_once './connection_sql.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="style.css" rel="stylesheet" type="text/css" media="screen" />


        <title>Search Vehicle</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">


            <script language="JavaScript" src="js/search_deduction.js"></script>



    </head>

    <body>

              <?php if (isset($_GET['cur'])) { ?>
            <input type="hidden" value="<?php echo $_GET['cur']; ?>" id="cur" />
            <?php
        } else {
            ?>
            <input type="hidden" value="" id="cur" />
            <?php
        }
        ?>
     
        <div id="filt_table" class="CSSTableGenerator">  
            
            <table id="example" class="stripe row-border order-column" style="width:100%">
                <thead>
                    <tr>
                      <th>Deduction Ref</th>
                    <th>Driver Name</th>
                    <th>Date</th>   
                       
                       
                      
                    </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT * from deduction";

                 $sql = $sql . " order by od_ref limit 50";


                $stname = "";
                if (isset($_GET['stname'])) {
                    $stname = $_GET["stname"];
                }

                foreach ($conn->query($sql) as $row) {
                    $cuscode = $row['od_ref'];

                     $sql2 = "Select * from driver_master_file where driver_ref = '" . $row['driver_ref'] . "' ";
                    $result = $conn->query($sql2);
                    $row2 = $result->fetch();

                    $dpt_name = $row2['driver_name'];
                  
                        echo "<tr>               
                            
                              <td onclick=\"custno('$cuscode', '$stname');\">" . $cuscode . "</a></td>
                              <td onclick=\"custno('$cuscode', '$stname');\">" . $dpt_name .  "</a></td>
                              <td onclick=\"custno('$cuscode', '$stname');\">" . $row['date'] . "</a></td>
                             
                             

                              
                              </tr>";
                  
                }
                ?>
            </tbody>
                <tfoot>
                    <tr>
                      <th>Deduction Ref</th>
                    <th>Driver Name</th>
                    <th>Date</th>   
                      
                      
                    </tr>
                </tfoot>
            </table>
        </div>



     





        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/fixedcolumns/3.2.6/js/dataTables.fixedColumns.min.js"></script>

        <script>
            $(document).ready(function () {
// Setup - add a text input to each footer cell
                $('#example tfoot th').each(function (i) {
                    var title = $('#example thead th').eq($(this).index()).text();
                    $(this).html('<input type="text" placeholder="Search ' + title + '" data-index="' + i + '" />');
                });

// DataTable
                var table = $('#example').DataTable({
                    scrollY: "300px",
                    scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    fixedColumns: true
                });

// Filter event handler
                $(table.table().container()).on('keyup', 'tfoot input', function () {
                    table
                            .column($(this).data('index'))
                            .search(this.value)
                            .draw();
                });
            });
        </script>

    </body>
</html>
