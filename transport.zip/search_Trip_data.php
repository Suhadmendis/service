<?php

session_start();



include_once './connection_sql.php';

if ($_GET["Command"] == "pass_quot") {

    $_SESSION["custno"] = $_GET['custno'];

    header('Content-Type: text/xml');
    echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";

    $ResponseXML = "";
    $ResponseXML .= "<salesdetails>";

    $cuscode = $_GET["custno"];

    $sql = "select * from trip where trip_ref= '" . $cuscode . "'";

    $sql = $conn->query($sql);
    if ($row = $sql->fetch()) {

        $vehicle_ref = $row['vehicle_ref'];
        $driver_ref = $row['driver_ref'];
        $cleaner_ref= $row['cleaner_ref'];
        $item_ref = $row['item_ref'];
      
        $ResponseXML .= "<id><![CDATA[" . $row['trip_ref'] . "]]></id>";
        $ResponseXML .= "<str_customername1><![CDATA[" . $row['vehicle_ref'] . "]]></str_customername1>";
        $ResponseXML .= "<str_customername2><![CDATA[" . $row['date'] . "]]></str_customername2>";
        $ResponseXML .= "<str_customername4><![CDATA[" . $row['opening_km'] . "]]></str_customername4>";
        $ResponseXML .= "<str_customername5><![CDATA[" . $row['closing_km'] . "]]></str_customername5>";
        $ResponseXML .= "<str_customername6><![CDATA[" . $row['mileage'] . "]]></str_customername6>";
        $ResponseXML .= "<str_customername7><![CDATA[" . $row['driver_ref'] . "]]></str_customername7>";
        $ResponseXML .= "<str_customername8><![CDATA[" . $row['cleaner_ref'] . "]]></str_customername8>";
        $ResponseXML .= "<str_customername9><![CDATA[" . $row['remark'] . "]]></str_customername9>";
        $ResponseXML .= "<str_customername10><![CDATA[" . $row['amount'] . "]]></str_customername10>";
        $ResponseXML .= "<str_customername11><![CDATA[" . $row['damount'] . "]]></str_customername11>";
        $ResponseXML .= "<str_customername12><![CDATA[" . $row['camount'] . "]]></str_customername12>";
        $ResponseXML .= "<str_customername13><![CDATA[" . $row['item_ref'] . "]]></str_customername13>";
        $ResponseXML .= "<str_customername14><![CDATA[" . $row['item_name'] . "]]></str_customername14>";
        $ResponseXML .= "<str_customername15><![CDATA[" . $row['department'] . "]]></str_customername15>";
        $ResponseXML .= "<str_customername16><![CDATA[" . $row['run_no'] . "]]></str_customername16>";
 
        $sql2 = "Select * from driver_master_file where driver_ref='" . $driver_ref . "'";
        $result = $conn->query($sql2);
        $row2 = $result->fetch();
        
        $sql3 = "Select * from item_master_file where item_ref='" . $item_ref . "'";
        $result = $conn->query($sql3);
        $row3 = $result->fetch();

        $sql4 = "Select * from cleaner_master where cleaner_ref='" . $cleaner_ref . "'";
        $result = $conn->query($sql4);
        $row4= $result->fetch();
  
        $sql5 = "Select * from vehicle_master1 where vehicle_ref='" . $vehicle_ref . "'";
        $result = $conn->query($sql5);
        $row5= $result->fetch();

        $vehicle_ref1 = $row2['driver_name'];
        $driver_ref1 = $row3['item_name'];
        $cleaner_ref1= $row4['cleaner_name'];
        $item_ref1 = $row5['vehicle_number'];

        $ResponseXML .= "<vehicle_ref1><![CDATA[$vehicle_ref1]]></vehicle_ref1>";
        $ResponseXML .= "<driver_ref1><![CDATA[$driver_ref1]]></driver_ref1>";
        $ResponseXML .= "<cleaner_ref1><![CDATA[$cleaner_ref1]]></cleaner_ref1>";
        $ResponseXML .= "<item_ref1><![CDATA[$item_ref1]]></item_ref1>";
    }

   $ResponseXML .= "<stname><![CDATA[" . $_GET['stname'] . "]]></stname>";

    $ResponseXML .= "</salesdetails>";
    echo $ResponseXML;
}

?>
